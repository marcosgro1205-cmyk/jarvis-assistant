# Jarvis Mobile — prototipo iniziale

Questa è una prima interfaccia web mobile con:
- pulsante per avviare il riconoscimento vocale del browser;
- risposta vocale in italiano tramite sintesi vocale del browser;
- schermata mobile in stile futuristico.

## Importante
Questa versione **non è ancora collegata a un modello AI** e non accede a Outlook, Teams, Fatture in Cloud, MelaWorks o dati aziendali. Le risposte sono dimostrative. Non inserire dati riservati.

## Avvio locale
Apri `index.html` in un browser compatibile (preferibilmente Chrome). Concedi il permesso al microfono. Il riconoscimento vocale può dipendere dal browser, dalla connessione e dalle impostazioni del dispositivo.

## Pubblicazione
Il file può essere pubblicato con GitHub Pages dopo averlo caricato nella cartella principale del repository.
